export const BasicShader: {
	uniforms: {};
	vertexShader: string;
	fragmentShader: string;
};
