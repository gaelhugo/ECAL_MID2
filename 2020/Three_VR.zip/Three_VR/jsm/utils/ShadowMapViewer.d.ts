import { Light } from '../../../src/Three';

export class ShadowMapViewer {

	constructor( light: Light )

}



